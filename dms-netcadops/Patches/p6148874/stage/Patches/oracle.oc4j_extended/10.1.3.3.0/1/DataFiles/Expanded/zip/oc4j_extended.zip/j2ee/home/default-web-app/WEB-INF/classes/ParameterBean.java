
public class ParameterBean {
    public void setIntProperty(int i) {
        System.out.println("Set int property: " + i);
    }


    public void setStringProperty(String i) {
        System.out.println("Set String property: " + i);
    }


    public void setObjectProperty(Object i) {
        System.out.println("Set Object property: " + i);
    }


    public void setFloatProperty(float i) {
        System.out.println("Set float property: " + i);
    }


    public void setByteProperty(byte i) {
        System.out.println("Set byte property: " + i);
    }
}