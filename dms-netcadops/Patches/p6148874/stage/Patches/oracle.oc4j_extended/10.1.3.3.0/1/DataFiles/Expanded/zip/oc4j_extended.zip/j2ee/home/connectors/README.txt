This directory is for storing stand-alone JCA-compliant resource adapters.
Each resource adapter is stored in a separate subdirectory, with the
deployment name as the name of the subdirectory.
