#
# README.txt for $ORACLE_HOME/j2ee/home/jazn/config
#

Description
-----------
jazn.xsd 
  - schema file for jazn.xml

jazn-data.xsd 
  - schema file for jazn-data.xml

ldap_login_module.template
  - template file for the 3rd party LDAP login module configuration
	
sample_login_module_ad.xml 
  - sample login module configuration for an Active Directory

sample_login_module_sun.xml
  - sample login module configuration for a SunOne Directory





