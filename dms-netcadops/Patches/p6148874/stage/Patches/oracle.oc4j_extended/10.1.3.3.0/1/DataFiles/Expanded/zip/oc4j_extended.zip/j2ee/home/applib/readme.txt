This directory should be used to place common jar files, and they'll be loaded
by default and will be available to all j2ee applications deployed to this OC4J
instance.
