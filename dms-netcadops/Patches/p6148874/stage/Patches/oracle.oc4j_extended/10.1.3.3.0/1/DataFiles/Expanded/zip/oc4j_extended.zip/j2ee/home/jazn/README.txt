JAAS provider (a.k.a. "JAZN") README.txt
========================================

Other README.txt(s)
-------------------

Please read the following before you proceed with JAZN-OC4J:

1) config/README.txt
- contains important info about configuring JAZN and JAZN-OC4J,
plus information for configuring 3rd party LDAP Login Module.

